package com.hutech.GiuaKiJava.repository;

import com.hutech.GiuaKiJava.model.PhongBan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PhongBanRepository extends JpaRepository<PhongBan, String> {
}

