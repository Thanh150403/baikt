package com.hutech.GiuaKiJava.repository;

import com.hutech.GiuaKiJava.model.NhanVien;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NhanVienRepository extends JpaRepository<NhanVien, String> {
}

