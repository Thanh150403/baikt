package com.hutech.GiuaKiJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiuaKiJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiuaKiJavaApplication.class, args);
	}

}
