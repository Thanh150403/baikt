package com.QLNS._1.repository;

import com.QLNS._1.entity.PhongBan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PhongBanRepository extends JpaRepository<PhongBan, String> {
}
